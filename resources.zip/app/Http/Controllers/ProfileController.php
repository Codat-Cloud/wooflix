<?php

namespace App\Http\Controllers;

use App\Http\Requests\ProfileUpdateRequest;
use App\Models\Order;
use App\Models\Review;
use App\Models\SiteSetting;
use App\Models\Wishlist;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\View\View;
use Barryvdh\DomPDF\Facade\Pdf;

class ProfileController extends Controller
{
    public function dashboard()
    {
        $orders = Order::with(['items.product:id,slug,name,main_image'])
            ->where('user_id', auth()->id())
            ->latest()
            ->take(2)
            ->get();

        $latestReview = Review::with('product:id,slug,name')
            ->where('user_id', auth()->id())
            ->where('is_approved', true)
            ->latest()
            ->first();

        $wishlist = Wishlist::with('product:id,slug,name,main_image')
            ->where('user_id', auth()->id())
            ->latest()
            ->take(6)
            ->get();

        return view('dashboard', compact('orders', 'latestReview', 'wishlist'));
    }

    public function orders()
    {
        $orders = Order::with([
            'items.product:id,slug,name,main_image',
        ])
            ->where('user_id', auth()->id())
            ->where('status', 'confirmed')
            ->latest()
            ->paginate(10);

        return view('profile.orders', compact('orders'));
    }

    public function wishlist()
    {
        // Fetch user wishlist with exact product and variant relation datasets
        $wishlistItems = Wishlist::with([
            'product:id,slug,name,main_image',
            'variant:id,slug,name,price,sale_price,stock'
        ])
            ->where('user_id', auth()->id())
            ->latest()
            ->paginate(12);

        return view('profile.wishlist', [
            'wishlist' => $wishlistItems
        ]);
    }

    public function wishlistRemove($id)
    {
        // Find the item ensuring it belongs strictly to the currently authenticated user
        $item = Wishlist::where('id', $id)
            ->where('user_id', auth()->id())
            ->firstOrFail();

        $item->delete();

        return back()->with('success', 'Item removed from your wishlist pack!');
    }


    /**
     * Display the user's profile form.
     */
    public function edit(Request $request): View
    {
        return view('profile.edit', [
            'user' => $request->user(),
        ]);
    }

    /**
     * Update the user's profile information.
     */
    public function update(ProfileUpdateRequest $request): RedirectResponse
    {
        $request->user()->fill($request->validated());

        if ($request->user()->isDirty('email')) {
            $request->user()->email_verified_at = null;
        }

        $request->user()->save();

        return Redirect::route('profile.edit')->with('status', 'profile-updated');
    }

    /**
     * Delete the user's account.
     */
    public function destroy(Request $request): RedirectResponse
    {
        $request->validateWithBag('userDeletion', [
            'password' => ['required', 'current_password'],
        ]);

        $user = $request->user();

        Auth::logout();

        $user->delete();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return Redirect::to('/');
    }

    public function invoice(Order $order)
    {
        abort_if($order->user_id !== auth()->id(), 403);
        $order->load(['items.product']);

        $settings = SiteSetting::pluck('value', 'key')->toArray();

        // Web view gets the buttons
        $isPdf = false;

        return view('invoices.order-invoice', compact('order', 'settings', 'isPdf'));
    }

    public function invoicePdf(Order $order)
    {
        abort_if($order->user_id !== auth()->id(), 403);
        $order->load(['items.product']);

        $settings = SiteSetting::pluck('value', 'key')->toArray();

        // PDF view hides the buttons explicitly
        $isPdf = true;

        $pdf = Pdf::loadView('invoices.order-invoice', compact('order', 'settings', 'isPdf'));

        // Optional Dompdf optimization for local assets
        $pdf->setOption([
            'isHtml5ParserEnabled' => true,
            'isRemoteEnabled' => true
        ]);

        return $pdf->download($order->order_number . '.pdf');
    }

    public function shippingLabel(Order $order)
    {
        // Security gate: block unauthorized visual access
        abort_unless(auth()->user() && auth()->user()->hasRole('admin'), 403);

        // Eager load nested items, products, and variant variations
        $order->load(['items.product']);

        // Pull key-value array configuration maps for header/footer assets
        $settings = SiteSetting::pluck('value', 'key')->toArray();

        return view('invoices.shipping-label', compact('order', 'settings'));
    }
}
