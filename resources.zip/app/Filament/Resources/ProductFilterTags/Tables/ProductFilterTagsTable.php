<?php

namespace App\Filament\Resources\ProductFilterTags\Tables;

use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\IconColumn;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class ProductFilterTagsTable
{
    public static function configure(Table $table): Table
    {
        return $table
        ->reorderable()
            ->columns([
                TextColumn::make('type')
                    ->badge(),

                TextColumn::make('name')
                    ->searchable(),

                TextColumn::make('slug'),

                IconColumn::make('is_active')
                    ->boolean(),

                TextColumn::make('sort_order'),
            ])
            ->filters([
                //
            ])
            ->recordActions([
                EditAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }
}
