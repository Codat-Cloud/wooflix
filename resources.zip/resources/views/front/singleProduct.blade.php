@extends('layouts.front')

@section('content')
{{-- <pre>
{{ dd($product->variants->toArray()) }}
</pre> --}}
@php
$variants = $product->variants->map(function ($v) {
    return [
        'id' => $v->id,
        'name' => $v->name,
        'slug' => $v->slug,
        'price' => $v->price,
        'sale_price' => $v->sale_price,
        'stock' => (int)$v->stock,
    ];
});
@endphp
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    window.productVariants = {!! json_encode($variants) !!};

    window.productBase = {
        price: {{ $product->defaultVariant->price }},
        sale_price: {{ $product->defaultVariant->sale_price ?? 'null' }}
    };

</script>

@php
    // Check by user_id if logged in, otherwise session_id
    $cartQuery = \App\Models\CartItem::query();
    if(auth()->check()) {
        $cartQuery->where('user_id', auth()->id());
    } else {
        $cartQuery->where('session_id', session()->getId());
    }

    $cartVariantIds = $cartQuery->pluck('variant_id')
        ->filter()
        ->map(fn($id) => (int)$id)
        ->toArray();
    
@endphp

<script>
    window.cartVariantIds = @json($cartVariantIds);
</script>


    <nav aria-label="breadcrumb" class="breadcrumb-wrapper">
        <div class="container-xxl">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                @if($product->category)
                    <li class="breadcrumb-item">
                        <a href="{{ route('front.shop', ['cat' => $product->category->slug]) }}">{{ $product->category->name }}</a>
                    </li>
                @endif
                <li class="breadcrumb-item active" aria-current="page">{{ $product->name }}</li>
            </ol>
        </div>
    </nav>

        <!-- Product Details -->

    <section class="single-product-info">
      <div class="container-xxl product-page">
        <div class="row g-4">

          <!-- PRODUCT IMAGES -->
          <div class="col-lg-6">
              <div class="product-gallery" 
                x-data="{ 
                    activeIndex: 0, 
                    {{-- Merge main_image with the collection of secondary images --}}
                    images: [
                        '{{ asset('storage/' . $product->main_image) }}',
                        @foreach($product->galleryImages as $img)
                            '{{ asset('storage/' . $img->image) }}',
                        @endforeach
                    ],
                    next() {
                        this.activeIndex = (this.activeIndex + 1) % this.images.length;
                    },
                    prev() {
                        this.activeIndex = (this.activeIndex - 1 + this.images.length) % this.images.length;
                    }
                }">
                
                <div class="gallery-main">
                    {{-- Only show arrows if there is more than one image --}}
                    <template x-if="images.length > 1">
                        <button class="gallery-arrow left" @click="prev()"> ← </button>
                    </template>

                    <div class="image-frame">
                        <img id="mainImage"
                            :src="images[activeIndex]"
                            class="main-product-img" 
                            alt="{{ $product->name }}" />
                    </div>

                    <template x-if="images.length > 1">
                        <button class="gallery-arrow right" @click="next()"> → </button>
                    </template>
                </div>

                <div class="gallery-thumbs">
                    <template x-for="(img, index) in images" :key="index">
                        <img :src="img"
                            class="thumb"
                            :class="activeIndex === index ? 'active' : ''"
                            @click="activeIndex = index" />
                    </template>
                </div>
            </div>
          </div>

          <!-- PRODUCT INFO -->
          <div class="col-lg-6">
            <div class="product-info">
              <div class="single-product-rating">
                  @php $stats = $product->rating_stats; @endphp
                  <span class="rating-stars">
                      ⭐ {{ number_format($stats['average'], 1) }}
                  </span>

                  <span class="rating-divider">|</span>

                  <span class="rating-count">
                      {{ $stats['total'] }} {{ Str::plural('review', $stats['total']) }}
                  </span>
              </div>

            <h1 class="single-product-title">
                {{$product->name}}
            </h1>

              <h2 class="product-brand">
                  <b class="text-dark">From </b>
                  {{ $product->brand->name ?? 'Wooflix' }}
              </h2>

            <!-- Price -->
            <div x-data="{
                variants: window.productVariants || [],
                selected: null,
                inCartVariants: window.cartVariantIds || [],
                price: 0,
                mrp: null,
                adding: false,
                added: false,
                isOutOfStock: false,

                init() {
                    if (this.variants.length > 0) {
                        // Added null coalescing for safety
                        const currentVariant = this.variants.find(
                            v => Number(v.id) === Number({{ $selectedVariant->id ?? 0 }})
                        );
                        this.select(currentVariant || this.variants[0]);
                    } else {
                        this.price = window.productBase.sale_price ?? window.productBase.price;
                        this.mrp = window.productBase.sale_price ? window.productBase.price : null;
                        this.isOutOfStock = false;
                    }
                },

                select(v) {
                    this.selected = v;
                    this.price = v.sale_price ?? v.price;
                    this.mrp = v.sale_price ? v.price : null;

                    // UPDATE: Check if the currently clicked selection has zero stock items left
                    this.isOutOfStock = Number(v.stock) <= 0;

                    window.history.replaceState(
                        {},
                        '',
                        '/collection/{{ $product->slug }}/' + v.slug
                    );
                },

                isAdded() {
                    if (!this.selected || !this.selected.id) return false;
                    const cartIds = Array.isArray(this.inCartVariants) ? this.inCartVariants : [];
                    return cartIds.some(id => Number(id) === Number(this.selected.id));
                },

                discount() {
                    if (!this.mrp) return null;
                    return Math.round(((this.mrp - this.price) / this.mrp) * 100);
                }
            }" 
            @cart-updated.window="inCartVariants = [...($event.detail.variant_ids || [])]; adding = false; added = true; setTimeout(() => added = false, 2000);">

              <!-- PRICE -->
              <div class="product-price border-bottom">
                  <div>

              <span class="price" x-text="'₹' + price"></span>

                          <template x-if="mrp">
                              <span class="old-price" x-text="'MRP: ₹' + mrp"></span>
                          </template>

                          <template x-if="mrp">
                              <span class="discount" x-text="'(' + discount() + '% OFF)'"></span>
                          </template>

                      </div>

                      <div>
                          @livewire('front.wishlist', [
                                'productId' => $product->id,
                                'variantId' => null
                            ])
                      </div>
                  </div>

                <!-- VARIANTS -->
                <div class="product-variants py-2" x-show="variants.length > 1">
                    <div class="d-flex justify-content-between">
                        <h6 class="fw-bold">Select</h6>
                        <button class="btn border-0 text-decoration-underline" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSizeChart" aria-expanded="false" aria-controls="collapseSizeChart">
                            Size Chart
                        </button>
                    </div>

                    <div class="variant-options">

                        <template x-for="v in variants" :key="v.id">

                            <div class="variant-item">

                                <button 
                                    class="variant-btn"
                                    :class="selected?.id === v.id ? 'active' : ''"
                                    @click="select(v)"
                                >

                                    <span x-text="v.name"></span>

                                    <template x-if="v.sale_price">
                                        <span class="variant-badge" 
                                            x-text="Math.round(((v.price - v.sale_price)/v.price)*100) + '% OFF'">
                                        </span>
                                    </template>

                                </button>

                            </div>

                        </template>

                    </div>
                </div>



                <div class="collapse" id="collapseSizeChart">
                <div class="card card-body border-0 p-0">
                    <img src="{{ asset('storage/' . $product->size_chart_image) }}" class="img-fluid" alt="{{ "Size Chart For - " . $product->name}}">
                </div>
                </div>


                    <button 
                        class="btn add-cart-btn w-100"
                        :class="{
                            'btn-orange': !adding && !isAdded() && !isOutOfStock,
                            'btn-secondary text-decoration-line-through': isOutOfStock || adding,
                            'btn-success': isAdded() && !isOutOfStock
                        }"
                        :disabled="adding || isAdded() || isOutOfStock"
                        @click="
                            if (adding || isAdded() || isOutOfStock) return;

                            if (!selected || !selected.id) {
                                alert('Please select a variant first');
                                return;
                            }

                            adding = true;

                            window.dispatchEvent(new CustomEvent('add-to-cart', {
                                detail: {
                                    variant_id: selected.id,
                                    product_id: {{ $product->id }}
                                }
                            }));
                        "
                    >
                        <template x-if="isOutOfStock">
                            <span>Out of Stock</span>
                        </template>
                        
                        <template x-if="!isOutOfStock">
                            <span>
                                <span x-show="!adding && !isAdded()">Add To Cart</span>
                                <span x-show="adding">Adding...</span>
                                <span x-show="isAdded()">Already in Cart ✓</span>
                            </span>
                        </template>
                    </button>
              </div>



            <!-- OFFERS -->
            <div class="product-offers">
                <h5 class="offers-title">
                  <svg width="20" height="20" class="w-5 h-5 inline-block mb-1 text-orange-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1" d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 110 4v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 110-4V7a2 2 0 00-2-2H5z" />
                  </svg>
                   Available Offers</h5>

                <div class="offers-grid">
                    @forelse($coupons as $coupon)
                        <div class="offer-card {{ $coupon->is_best ? 'best-offer' : '' }}">
                            @if($coupon->is_best)
                                <span class="offer-ribbon">BEST</span>
                            @endif

                            <div class="offer-content">
                                {{-- Uses the Accessor we made: display_title --}}
                                <h6>{{ $coupon->display_title }}</h6>
                                
                                {{-- Fallback description logic --}}
                                <p>
                                    @if($coupon->description)
                                        {{ $coupon->description }}
                                    @elseif($coupon->min_spend > 0)
                                        Orders above ₹{{ number_format($coupon->min_spend, 0) }}
                                    @else
                                        Use coupon on checkout
                                    @endif
                                </p>
                            </div>

                            <button class="coupon-btn" data-code="{{ $coupon->code }}" onclick="copyCoupon(this)">
                                <span class="btn-text">Copy</span>
                            </button>
                        </div>
                    @empty
                        <p class="text-muted">No offers available at the moment.</p>
                    @endforelse
                </div>
            </div>

            
                @livewire('front.pincode-checker')

              <!-- ACCORDION -->

              <div class="accordion product-accordion mt-3">
                <div class="accordion-item">
                  <h2 class="accordion-header">
                    <button
                      class="accordion-button collapsed"
                      data-bs-toggle="collapse"
                      data-bs-target="#details"
                    >
                      Product Details
                    </button>
                  </h2>

                  <div id="details" class="accordion-collapse collapse show">
                    <div class="accordion-body">
                      {!!$product->short_description!!}
                    </div>
                  </div>
                </div>

                <div class="accordion-item mt-3">
                  <h2 class="accordion-header">
                    <button
                      class="accordion-button collapsed"
                      data-bs-toggle="collapse"
                      data-bs-target="#additional"
                    >
                      Additional Information
                    </button>
                  </h2>

                  <div id="additional" class="accordion-collapse collapse">
                    <div class="accordion-body">
                      {!!$product->description!!}

                      <br>

                      @if($product->infographicImages->isNotEmpty())
                            <div class="product-infographics-grid row g-3 mt-4">
                                @foreach($product->infographicImages as $infographic)
                                    <div class="col-12 mb-3">
                                        <img src="{{ asset('storage/' . $infographic->image) }}" 
                                            class="img-fluid rounded" 
                                            alt="Product Feature Breakdown Infographic" 
                                            loading="lazy">
                                    </div>
                                @endforeach
                            </div>
                        @endif
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

<section class="frequently-bought-together container-xxl my-5">
    <h4 class="fw-bold text-dark mb-4">🐾Frequently Bought Together</h4>
    @livewire('front.product-grid', [
        'mode' => 'fbt', 
        'parentProductId' => $product->id
    ], key('fbt-grid-'.$product->id))
</section>

<section class="related-products container-xxl my-5">
    <h4 class="fw-bold text-dark mb-4">🐾 More Items You Might Like</h4>
    @livewire('front.product-grid', [
        'mode' => 'related', 
        'parentProductId' => $product->id, 
        'categoryId' => $product->category_id
    ], key('related-grid-'.$product->id))
</section>


    <section class="reviews-section container-xxl my-5">
      <h4 class="mb-3">Customer Reviews</h4>

      <ul class="nav nav-tabs review-tabs">
        <li class="nav-item">
          <button
            class="nav-link active"
            data-bs-toggle="tab"
            data-bs-target="#reviewsTab"
          >
            Reviews
          </button>
        </li>

        <li class="nav-item">
          <button
            class="nav-link"
            data-bs-toggle="tab"
            data-bs-target="#writeReviewTab"
          >
            Write Review
          </button>
        </li>

        <li class="nav-item">
          <button
            class="nav-link"
            data-bs-toggle="tab"
            data-bs-target="#questionTab"
          >
            Ask Question?
          </button>
        </li>
      </ul>

      <div class="tab-content mt-4">
        <!-- REVIEWS TAB -->

        <div class="tab-pane fade show active" id="reviewsTab">
          <div class="">
            <div class="review-summary">
              @php $stats = $product->rating_stats; @endphp

              <div class="summary-left">
                  {{-- Display the dynamic average (e.g., 4.8) --}}
                  <h2 class="rating-average">{{ number_format($stats['average'], 1) }}</h2>

                  <div class="rating-stars">
                      {{-- Dynamic Star Logic based on average --}}
                      @for ($i = 1; $i <= 5; $i++)
                          @if ($i <= round($stats['average']))
                              ★
                          @else
                              <span style="color: #ccc;">★</span>
                          @endif
                      @endfor
                  </div>

                  <p class="total-reviews">Based on {{ $stats['total'] }} {{ Str::plural('review', $stats['total']) }}</p>
              </div>

              <div class="summary-bars">
                  {{-- Loop through the details (5 down to 1) --}}
                  @foreach($stats['details'] as $star => $data)
                      <div class="rating-row">
                          <span>{{ $star }} ★</span>
                          <div class="rating-bar">
                              {{-- Dynamic width based on the calculated percentage --}}
                              <div class="rating-fill" style="width: {{ $data['percentage'] }}%"></div>
                          </div>
                          <span class="rating-count">{{ $data['count'] }}</span>
                      </div>
                  @endforeach
              </div>
          </div>
          </div>

          <div class="review-gallery">
              @php $imgIndex = 0; @endphp

              @foreach($product->reviews as $review)
                  @foreach($review->images as $image)
                      <img 
                          src="{{ asset('storage/' . $image->image_path) }}" 
                          class="review-thumb"
                          onclick="openReviewGallery({{ $imgIndex }})"
                          alt="Customer photo"
                          lazyload="lazy"
                      >
                      @php $imgIndex++; @endphp
                  @endforeach
              @endforeach

              @if($imgIndex === 0)
                  <p class="text-muted small">No customer photos yet. Be the first!</p>
              @endif
          </div>

          <div class="row g-3 mt-3">
              @forelse($product->reviews as $review)
                  <div class="col-md-6">
                      <div class="review-card">
                          <div class="review-header">
                              <div>
                                  <strong>{{ $review->customer_name }}</strong>

                                  @if($review->is_verified_buyer)
                                      <span class="verified-badge">✔ Verified Buyer</span>
                                  @endif
                              </div>

                              <span class="review-rating text-warning">
                                  {{-- Output solid stars based on rating --}}
                                  @for($i = 1; $i <= 5; $i++)
                                      {{ $i <= $review->rating ? '★' : '☆' }}
                                  @endfor
                              </span>
                          </div>

                          <p>{{ $review->comment }}</p>

                          {{-- If the review has images, you can show them here --}}
                          @if($review->images->count() > 0)
                              <div class="review-images-mini mt-2 d-flex gap-2">
                                  @foreach($review->images as $rImg)
                                      <img src="{{ asset('storage/' . $rImg->image_path) }}" 
                                          alt="Review Photo" 
                                          class="rounded" 
                                          lazyload="lazy"
                                          style="width: 50px; height: 50px; object-fit: cover;">
                                  @endforeach
                              </div>
                          @endif
                      </div>
                  </div>
              @empty
                  <div class="col-12 text-center py-4">
                      <p class="text-muted">No reviews yet. Be the first to share your thoughts!</p>
                  </div>
              @endforelse
          </div>

          
        </div>

        <!-- WRITE REVIEW -->

        <div class="tab-pane fade" id="writeReviewTab">
          {{-- @livewire('front.write-review') --}}
          <livewire:front.write-review :productId="$product->id" />

        </div>

        <!-- ASK QUESTION -->

        <div class="tab-pane fade" id="questionTab">

          <div class="row g-4 my-4">
            <div class="col-12">
                <h5 class="fw-bold mb-4">Questions & Answers ({{ $product->questions->count() }})</h5>
            </div>

            @forelse($product->questions as $q)
                <div class="col-md-6">
                    <div class="review-card h-100 shadow-sm border-0 p-3 bg-white">
                        <div class="d-flex gap-2 mb-3">
                            <span class="badge bg-dark rounded-circle d-flex align-items-center justify-content-center" style="width: 24px; height: 24px;">Q</span>
                            <div>
                                <strong class="d-block text-dark">{{ $q->question }}</strong>
                                <small class="text-muted" style="font-size: 0.75rem;">
                                    By {{ $q->name }} • {{ $q->created_at->format('d M, Y') }}
                                </small>
                            </div>
                        </div>

                        @if($q->answer)
                        <div class="admin-answer-box p-3 rounded" style="background-color: #fff9f0; border-left: 3px solid #ff9800;">
                            <div class="d-flex gap-2">
                                <span class="badge bg-orange rounded-circle d-flex align-items-center justify-content-center" style="width: 24px; height: 24px; color: white;">A</span>
                                <div>
                                    <p class="mb-0 text-dark small">{{ $q->answer }}</p>
                                    <small class="text-muted fw-bold" style="font-size: 0.7rem; text-transform: uppercase;">
                                        — Wooflix Expert Team • {{ $q->updated_at->format('d M, Y') }}
                                    </small>
                                </div>
                            </div>
                        </div>
                        @endif
                    </div>
                </div>
            @empty
                <div class="col-12">
                    <div class="text-center p-5 border rounded bg-light">
                        <i class="bi bi-chat-dots fs-1 text-muted"></i>
                        <p class="mt-2 text-muted italic">Have a question about this product? Ask us below!</p>
                    </div>
                </div>
            @endforelse
        </div>


          <livewire:front.ask-question :productId="$product->id" />

        </div>
      </div>
    </section>


    <div class="modal fade" id="reviewGalleryModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content bg-dark border-0">
                <div class="modal-body p-0 position-relative text-center">
                    {{-- Navigation Arrows --}}
                    <button class="gallery-arrow left" onclick="changeReviewImage(-1)">&#10094;</button>
                    
                    <img id="reviewGalleryImage" class="img-fluid rounded" style="max-height: 80vh;">

                    <button class="gallery-arrow right" onclick="changeReviewImage(1)">&#10095;</button>

                    {{-- Close Button --}}
                    <button type="button" class="btn-close btn-close-white position-absolute top-0 end-0 m-3" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="loginModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content p-3">

            <div class="modal-header border-0">
                <h5 class="modal-title">Login</h5>
                <button class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <div class="modal-body">

                <form id="loginForm">

                    <div class="mb-3">
                        <input 
                            type="email" 
                            class="form-control"
                            placeholder="Email"
                            id="loginEmail"
                        >
                    </div>

                    <div class="mb-3">
                        <input 
                            type="password" 
                            class="form-control"
                            placeholder="Password"
                            id="loginPassword"
                        >
                    </div>

                    <button type="submit" class="btn btn-orange w-100">
                        Login
                    </button>

                </form>

            </div>

        </div>
    </div>
</div>

    @push('scripts')
        <script>

            // Open login Modal
            // window.addEventListener('open-login-modal', () => {
            //    const modal = new bootstrap.Modal(document.getElementById('loginModal'));
            //    modal.show();
            //});


            document.addEventListener('DOMContentLoaded', () => {
                // 1. Dynamically build the array from PHP
                const reviewImages = [
                    @foreach($product->reviews as $review)
                        @foreach($review->images as $image)
                            "{{ asset('storage/' . $image->image_path) }}",
                        @endforeach
                    @endforeach
                ];

                let reviewImageIndex = 0;

            });

            function openReviewGallery(index) {
                reviewImageIndex = index;
                
                // Set the initial image
                document.getElementById("reviewGalleryImage").src = reviewImages[index];

                // Show the modal (Standard Bootstrap 5 way)
                const modalElement = document.getElementById('reviewGalleryModal');
                const myModal = new bootstrap.Modal(document.getElementById('reviewGalleryModal'));
                myModal.show();
            }

            function changeReviewImage(step) {
                reviewImageIndex += step;

                // Loop back logic
                if (reviewImageIndex < 0) reviewImageIndex = reviewImages.length - 1;
                if (reviewImageIndex >= reviewImages.length) reviewImageIndex = 0;

                // Update the image src
                document.getElementById("reviewGalleryImage").src = reviewImages[reviewImageIndex];
            }

            // window.addEventListener('notify', event => {
            //     const data = event.detail[0] || event.detail;
                
            //     Swal.fire({
            //         title: data.type === 'error' ? 'Oops!' : 'Success!',
            //         text: data.message,
            //         icon: data.type, // 'error', 'success', 'info', or 'warning'
            //         toast: true,
            //         position: 'top-end',
            //         showConfirmButton: false,
            //         timer: 3000,
            //         timerProgressBar: true,
            //     });
            // });

        </script>
    @endpush
 
@endsection